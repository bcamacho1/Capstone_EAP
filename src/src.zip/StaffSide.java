
import java.sql.SQLException;
import java.util.Scanner;

 

public class StaffSide {

    public static void main(String[] args) {
        String email;
        String password;
        int i = 1;
        Scanner in = new Scanner(System.in);
        String logMess = "Login to the database using your email.\n";
        String menuSelect = "Menu:\n"
                + "    C: Change a password of a staff member.\n"
                + "    D: Display all ther staff members in the database.\n"
                + "    I: Display and image path.\n"
                + "    P: Display an emergency procedure. \n"
                + "    Q: Quit.\n";
        
        
        String message;
        CapstoneImage img;
        Procedure proc;
        char choice;
        StaffMember mem;
        LoginServiceImplem login = new LoginServiceImplem();
        StaffMemberDAOImplem staff = new StaffMemberDAOImplem();
        FileDAOImplem file = new FileDAOImplem();
        
        try{
          while(i < 5){
            System.out.println(logMess);
            email = in.nextLine();
            System.out.println("Enter your password.");
            password = in.nextLine();
            if(login.login(email, password)){
                mem = staff.isStaffMemberAuthenticated(email, password);
                System.out.println(menuSelect);
                choice = in.nextLine().charAt(0);
                while(choice != 'q' && choice != 'Q'){
                    switch(choice){
                        case 'c':
                        case 'C':
                            //change the password of this user     
                            int id = mem.getEmployeeID();
                            System.out.println("Enter the new password.");
                            password = in.nextLine();
                            if(staff.changePassword(mem, password)){
                                System.out.println("Password was changed.");
                                mem = staff.getStaffMember(id);
                                System.out.println(mem.toString());
                            }else
                                System.out.println("Password was not changed.");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'd':
                        case 'D':
                            //display all contacts
                            staff.displayAllRows();
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'i':
                        case 'I':
                            //get an image
                            message = "Get a Image by ImageID, "
                                    + "input the ID of the image you'd like "
                                    + "to get: \n";
                            System.out.println(message);
                            img = new CapstoneImage();
                            img.setID(in.nextInt());
                            System.out.println("Image name:\n");
                            img.setImageName(in.nextLine());
                            System.out.println("Path:\n");
                            img.setURL(in.nextLine());
                            if(file.addImage(img))
                                System.out.println("Getting the image from the database."
                                        + img.toString());
                            else
                                System.out.println("Could not get the image from the database.");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'p':
                        case 'P':
                            //get a procedure
                            message = "Get a Procedure by ProcID, "
                                    + "input the ID of the Procedure you'd like "
                                    + "to get: \n";
                            System.out.println(message);
                            proc = new Procedure();
                            proc.setID(in.nextInt());
                            System.out.println("Procedure name:\n");
                            proc.setProcedure(in.nextLine());
                            System.out.println("Path:\n");
                            proc.setURL(in.nextLine());
                            if(file.addProcedure(proc))
                                System.out.println("Getting the procedure from the database"
                                        + proc.toString());
                            else 
                                System.out.println("Counld not get the procedure from the database.");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'q':
                        case 'Q':
                            //quits the program
                            System.out.println("Thanks, come back soon.");
                            login.logout(mem);
                            mem = null;
                            i = 5;
                            break;
                    }
                }
            }
            i++;
            System.out.println("");
            System.out.println("Could not log in, your information is wrong - try again.\n");
          }
         }catch(SQLException exe){
             exe.printStackTrace();
         }
    }
}

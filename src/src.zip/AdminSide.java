
import java.sql.SQLException;
import java.util.Scanner;



public class AdminSide {

    public static void main(String[] args) {
        
        String email;
        String password;
        Scanner in = new Scanner(System.in);
        String lastName;
        String logMess = "Login to the database using your email.\n";
        String menuSelect = "Menu:\n"
                + "    A: Add a staff member to the database.\n"
                + "    B: Add an image to the database.\n"
                + "    C: Change a password of a staff member.\n"
                + "    D: Delete a staff member.\n"
                + "    F: Fetch a staff member by last name.\n"
                + "    G: Get a staff member by id.\n"
                + "    I: Check to see of a staff member is active.\n"
                + "    P: Print all staff members in the database. \n"
                + "    T: Add a procedure to the database.\n"
                + "    U: Update a staff member.\n"
                + "    V: Check to see if a staff member is valid.\n"
                + "    Q: Quit.\n";
        
        String message;
        CapstoneImage img;
        Procedure proc;
        int i = 1;
        char choice = 'z';
                
        
        StaffMember mem = new StaffMember();
        StaffMember member = new StaffMember();
        
        LoginServiceImplem login = new LoginServiceImplem();
        StaffMemberDAOImplem staff = new StaffMemberDAOImplem();
        FileDAOImplem file = new FileDAOImplem();
        try{
          while(i < 5){
            System.out.println(logMess);
            email = in.nextLine();
            System.out.println("Enter your password.");
            password = in.nextLine();
            if(login.login(email, password)){
                mem = staff.isStaffMemberAuthenticated(email, password);
                
                System.out.println(menuSelect);
                choice = in.nextLine().charAt(0);
                while(choice != 'q' && choice != 'Q'){
                    switch(choice){
                        case 'a':
                        case 'A':
                            //add staffmember to database
                            message = "Adding a staff member by StaffID, "
                                    + "input the ID of the Staff you'd like "
                                    + "to add: \n";
                            System.out.println(message);
                            member = new StaffMember();
                            member.setEmployeeID(in.nextInt());
                            in.nextLine();
                            System.out.println("First Name:\n");
                            member.setFirstName(in.nextLine());
                            System.out.println("Last Name:\n");
                            member.setLastName(in.nextLine());
                            System.out.println("Email:\n");
                            member.setEmail(in.nextLine());
                            System.out.println("Phone:\n");
                            member.setPhone(in.nextLine());
                            System.out.println("Password:\n");
                            member.setPassword(in.nextLine());
                            System.out.println("Position:\n");
                            member.setPosition(in.nextLine());
                            if(staff.addStaffMember(member))
                                System.out.println(member.toString() + " was added.\n");
                            else
                                System.out.println("Staff member was not added.");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'b':
                        case 'B':
                            //add image to database
                            img = new CapstoneImage();
                            message = "Adding an Image by ImageID, "
                                    + "input the ID of the Image you'd like "
                                    + "to add: \n";
                            System.out.println(message);
                            img.setID(in.nextInt());
                            in.nextLine();
                            System.out.println("Path:\n");
                            img.setURL(in.nextLine());
                            System.out.println("Image name:\n");
                            img.setImageName(in.nextLine());
                            if(file.addImage(img))
                                System.out.println(img.toString() + " was added.\n");
                            else
                                System.out.println(img.toString() + " was not added.\n");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'c':
                        case 'C':
                            //change password
                            message = "Fetching a staff member by StaffID, "
                                    + "input the ID of the Staff who's password you'd like "
                                    + "to update: \n";
                            System.out.println(message);
                            int id = in.nextInt();
                            member = staff.getStaffMember(id);
                            in.nextLine();
                            System.out.println("Enter the new password.");
                            password = in.nextLine();
                            if(staff.changePassword(member, password)){
                                System.out.println("Password was changed.");
                                member = staff.getStaffMember(id);
                                System.out.println(member.toString());
                            }else
                                System.out.println("Password was not changed.");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'd':
                        case 'D':
                            //delete
                            message = "Updating a staff member by StaffID, "
                                    + "input the ID of the Staff you'd like "
                                    + "to delete: \n";
                            System.out.println(message);
                            if(staff.delete(in.nextInt()))
                                System.out.println("The Staff Member was removed.\n");
                            else 
                                System.out.println("The Staff Member was not removed.\n");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'f':
                        case 'F':
                            //fetch by name
                            message = "Fetching a staff member by Last Name, "
                                    + "input the last name of the Staff you'd like "
                                    + "to retrieve: \n";
                            System.out.println(message);
                            lastName = in.nextLine();
                            member = staff.fetchByName(lastName);
                            System.out.println("The Staff Member was retrieved. " 
                                    + member.toString());
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'g':
                        case 'G':
                            //get staff by staffID
                            message = "Input the ID of the Staff you'd like "
                                    + "to get: \n";
                            System.out.println(message);
                            member = staff.getStaffMember(in.nextInt());
                            System.out.println("The Staff Member was retrieved. "
                                    + member.toString());
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'i':
                        case 'I':
                            //is staffmember active
                            message = "Input the last name of the Staff you'd like "
                                    + "to see is active: \n";
                            System.out.println(message);
                            lastName = in.nextLine();
                            if(staff.isActive(lastName)){
                                System.out.println("Is an active Staff Member. \n");
                                member = staff.fetchByName(lastName);
                                System.out.println(member.toString());
                            }else 
                                System.out.println("Is not an active Staff Member. \n");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'p':
                        case 'P':
                            //print staffmembers in database
                            staff.displayAllRows();
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'q':
                        case 'Q':
                            //quits the program
                            System.out.println("Thanks, come back soon.");
                            login.logout(mem);
                            member = null;
                            mem = null;
                            i = 5;
                            break;
                      /*case 's':
                      * case 'S':
                      * //sort list?
                      * break;*/
                        case 't':
                        case 'T':
                            //add procedure to database
                            proc = new Procedure();
                            message = "Adding a Procedure by ProcID, "
                                    + "input the ID of the Procedure you'd like "
                                    + "to add: \n";
                            System.out.println(message);
                            proc.setID(in.nextInt());
                            in.nextLine();
                            System.out.println("Path:\n");
                            proc.setURL(in.nextLine());
                            System.out.println("Image name:\n");
                            proc.setProcedure(in.nextLine());
                            if(file.addProcedure(proc))
                                System.out.println(proc.toString() + " was added.\n");
                            else
                                System.out.println("Procedure could not be added,"
                                        + "please try later.");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'u':
                        case 'U':
                            //update one staffmember
                            message = "Updating a staff member by StaffID, "
                                    + "input the ID of the Staff you'd like "
                                    + "to update: \n";
                            System.out.println(message);
                            member = new StaffMember();
                            member.setEmployeeID(in.nextInt());
                            in.nextLine();
                            System.out.println("First Name:\n");
                            member.setFirstName(in.nextLine());
                            System.out.println("Last Name:\n");
                            member.setLastName(in.nextLine());
                            System.out.println("Email:\n");
                            member.setEmail(in.nextLine());
                            System.out.println("Phone:\n");
                            member.setPhone(in.nextLine());
                            System.out.println("Position:\n");
                            member.setPosition(in.nextLine());
                            if(staff.update(member))
                                System.out.println(member.toString() + " was updated.\n");
                            else
                                System.out.println("Staff member could not be updated.");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                        case 'v':
                        case 'V':
                            //is staffmember valid
                            System.out.println("Type the last name of the Staff "
                                    + "Member you would like to check for.");
                            lastName = in.nextLine();
                            if(staff.isStaffMemberValid(lastName)){
                                System.out.println("Is a valid Staff Member. \n");
                                member = staff.fetchByName(lastName);
                                System.out.println(member.toString());
                            }else
                                System.out.println("Is a not valid Staff Member. \n");
                            System.out.println(menuSelect);
                            choice = in.nextLine().charAt(0);
                            break;
                    }
                }
            }
            i++;
            System.out.println("");
            System.out.println("Could not log in, your information is wrong - try again.\n");
          }
        }catch(SQLException exe){
            exe.printStackTrace();
        }
    }
}
